package app.dto;

import java.math.BigDecimal;

/**
 * Created by User on 24.7.2017 г..
 */
public class IngredientDto extends BaseIngredientDto {


}
