import orm.Connector;
import orm.EntityManager;
import orm.EntityManagerBuilder;
import orm.strategies.DropCreateStrategy;
import orm.strategies.UpdateStrategy;

import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import static orm.scanner.EntityScanner.getAllEntities;

public class Main {
    public static void main(String[] args) throws SQLException, IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException, ClassNotFoundException {
        //List<Class> allEntities = getAllEntities(System.getProperty("user.dir"));

        EntityManager em = new EntityManagerBuilder()
                .configureConnectionString()
                  .setAdapter("jdbc")
                  .setDriver("mysql")
                  .setHost("localhost")
                  .setPort("3306")
                  .setUser("root")
                  .setPass("limerix")
                  .createConnection()
                .configureCreationType()
                  .set(DropCreateStrategy.class)
                .setDataSource("my_db")
                .build();

        User user = new User("Nakov", "alabala", 30, new Date(), new Date());
        //user.setId(1);
        em.persist(user);
    }
}
