package orm;

import java.lang.reflect.Field;
import java.sql.SQLException;

public interface TableCreator {
    boolean doCreate(Class entity) throws SQLException;
    String getTableName(Class entity);
    String getDBType (Field field);
}
