package orm.strategies;

import annotations.Column;
import annotations.Entity;
import annotations.Id;
import orm.TableCreator;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.SQLException;

public class DatabaseTableCreator implements TableCreator {
    private Connection connection;
    private String dataSource;

    public DatabaseTableCreator(Connection connection, String dataSource) {
        this.connection = connection;
        this.dataSource = dataSource;
    }

    @Override
    public boolean doCreate(Class entity) throws SQLException {
        String query = " CREATE TABLE " + this.dataSource + "." + this.getTableName(entity) + "( ";

        Field[] fields = entity.getDeclaredFields();

        for (int i = 0; i < fields.length; i++) {
            Field field = fields[i];
            field.setAccessible(true);

            query += " `" + field.getAnnotation(Column.class).name() + "` " + this.getDBType(field);

            if (field.isAnnotationPresent(Id.class)) {
                query += " PRIMARY KEY AUTO_INCREMENT";
            }

            if (i < fields.length - 1) {
                query += ", ";
            }

        }
        query += ")";

        return this.connection.prepareStatement(query).execute();
    }

    @Override
    public String getTableName(Class entity){
        String tableName = "";
        if(entity.isAnnotationPresent(Entity.class)){
            Entity annotation = (Entity)entity.getAnnotation(Entity.class);
            tableName = annotation.name();
        }
        if(tableName.equals("")){
            tableName = entity.getSimpleName();
        }
        return tableName;
    }

    @Override
    public String getDBType (Field field) {
        field.setAccessible(true);

        String mySQLType = "";

        switch (field.getType().getSimpleName()) {
            case "int":
            case "Integer":
                mySQLType = "INT";
                break;
            case "String":
                mySQLType = "VARCHAR(30)";
                break;
            case "Date":
                mySQLType = "DATETIME";
                break;
        }

        return mySQLType;
    }
}
