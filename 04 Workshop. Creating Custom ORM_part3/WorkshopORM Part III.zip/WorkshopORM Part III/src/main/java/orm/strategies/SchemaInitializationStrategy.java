package orm.strategies;

import orm.TableCreator;
import orm.scanner.EntityScanner;

import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.SQLException;

public interface SchemaInitializationStrategy {
    void execute() throws SQLException, IllegalAccessException, ClassNotFoundException, NoSuchMethodException, InstantiationException, InvocationTargetException;

    void setConnection(Connection connection);

    void setDataSource(String dataSource);

    void setCreator(TableCreator tableCreator);

    void setScanner(EntityScanner entityScanner);
}
