package orm.strategies;

import annotations.Column;
import annotations.Entity;
import annotations.Id;
import orm.TableCreator;
import orm.scanner.EntityScanner;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

public class UpdateStrategy extends AbstractStrategy {

    public UpdateStrategy() {
        super();
    }

    @Override
    public void execute() throws SQLException, IllegalAccessException, ClassNotFoundException, NoSuchMethodException, InstantiationException, InvocationTargetException {
        List<Class> entities = this.getAllEntities();

        for (Class entity : entities) {
            Field primary = this.getId(entity);
            primary.setAccessible(true);
            this.updateTable(entity, primary);
        }

    }


    private boolean updateTable(Class entity, Field primary) throws SQLException, IllegalAccessException {
        String tableName = this.tableCreator.getTableName(entity);

        if (!this.checkIfTableExists(tableName)) {
            this.tableCreator.doCreate(entity);
        }

        Field[] fields = entity.getDeclaredFields();
        for(int i = 1; i < fields.length; i++){
            Field currentField = fields[i];
            currentField.setAccessible(true);

            String fieldName = currentField.getAnnotation(Column.class).name();
            if(!this.checkIfFieldExists(tableName, fieldName)) {
                this.doAlter(tableName, currentField);
            }
        }
        return false;
    }


    private void doAlter(String tableName, Field field) throws SQLException {
        String fieldName = field.getAnnotation(Column.class).name();
        String query = "ALTER TABLE " + this.dataSource + "." + tableName + " ADD COLUMN " + fieldName + " " + this.tableCreator.getDBType(field);
        this.connection.prepareStatement(query).execute();
    }

    public void doDelete (Class<?> table, String criteria) throws Exception {
        String tableName = table.getAnnotation(Entity.class).name();
        if (!this.checkIfTableExists(tableName)) {
            throw new Exception("Table doesn't exist!");
        }

        String query = "DELETE FROM " + this.dataSource + "." + tableName + " WHERE " + criteria;
        this.connection.prepareStatement(query).execute();
    }


    private boolean checkIfTableExists (String tableName) throws SQLException {
        String query = "SELECT table_name FROM information_schema.tables" +
                " WHERE table_schema = '" + this.dataSource + "' AND table_name = '" + tableName + "' LIMIT 1;";

        ResultSet rs =  this.connection.prepareStatement(query).executeQuery();

        if (rs.first()) {
            return true;
        }
        return  false;
    }

    private boolean checkIfFieldExists (String tableName, String fildName) throws SQLException {
        String query = "SELECT COLUMN_NAME FROM information_schema.COLUMNS" +
                " WHERE TABLE_SCHEMA = '" + this.dataSource + "' AND TABLE_NAME = '" + tableName +
                "' AND COLUMN_NAME = '" + fildName + "';";

        ResultSet rs =  this.connection.prepareStatement(query).executeQuery();

        if (rs.first()) {
            return true;
        }
        return  false;
    }

    private Field getId(Class entity) throws SQLException, IllegalAccessException{
        return Arrays.stream(entity.getDeclaredFields())
                .filter(field -> field.isAnnotationPresent(Id.class))
                .findFirst()
                .orElseThrow(() -> new UnsupportedOperationException("object does not have primary key"));
    }
}
