package orm.strategies;

import annotations.Column;
import annotations.Entity;
import annotations.Id;
import orm.TableCreator;
import orm.scanner.EntityScanner;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public abstract class AbstractStrategy implements SchemaInitializationStrategy {
    private EntityScanner entityScanner;
    protected TableCreator tableCreator;
    protected Connection connection;
    protected String dataSource;

    public AbstractStrategy() {

    }

    @Override
    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void setDataSource(String dataSource) {
        this.dataSource = dataSource;
    }

    List<Class> getAllEntities() throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        return this.entityScanner.getAllEntities(System.getProperty("user.dir"));
    }

    @Override
    public void setCreator(TableCreator tableCreator) {
        this.tableCreator = tableCreator;
    }

    @Override
    public void setScanner(EntityScanner entityScanner) {
        this.entityScanner = entityScanner;
    }
}
