package orm;

import orm.strategies.*;

public class StrategyConfigurer {
    private EntityManagerBuilder entityManagerBuilder;

    public StrategyConfigurer(EntityManagerBuilder entityManagerBuilder) {
        this.entityManagerBuilder = entityManagerBuilder;
    }

    public <T extends AbstractStrategy> EntityManagerBuilder set(Class<T> strategyClass) throws IllegalAccessException, InstantiationException {
        AbstractStrategy strategy = strategyClass.newInstance();
        this.entityManagerBuilder.setStrategy(strategy);
        return this.entityManagerBuilder;
    }
}
