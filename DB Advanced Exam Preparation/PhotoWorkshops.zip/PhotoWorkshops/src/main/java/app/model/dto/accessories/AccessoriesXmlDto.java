package app.model.dto.accessories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * Created by Guest Lector on 08-Aug-17.
 */
@XmlRootElement(name = "accessories")
@XmlAccessorType(XmlAccessType.FIELD)
public class AccessoriesXmlDto {

    @XmlElement(name = "accessory")
    private List<AccessoryXMLDto> accessoryXMLDtos;

    public List<AccessoryXMLDto> getAccessoryXMLDtos() {
        return accessoryXMLDtos;
    }

    public void setAccessoryXMLDtos(List<AccessoryXMLDto> accessoryXMLDtos) {
        this.accessoryXMLDtos = accessoryXMLDtos;
    }
}
