package app.model.dto.lens;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlValue;
import java.math.BigDecimal;

/**
 * Created by Guest Lector on 08-Aug-17.
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class LensExportXmlDto {

    @XmlTransient
    private String make;

    @XmlTransient
    private Integer focalLength;

    @XmlTransient
    private BigDecimal aperture;

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public Integer getFocalLength() {
        return focalLength;
    }

    public void setFocalLength(Integer focalLength) {
        this.focalLength = focalLength;
    }

    public BigDecimal getAperture() {
        return aperture;
    }

    public void setAperture(BigDecimal aperture) {
        this.aperture = aperture;
    }

    @XmlValue
    public String getDesc () {
        return make + " " + focalLength + "mm f" + aperture;
    }
}
