package app.model.dto.photographers;

import app.model.dto.lens.LensExportXmlDto;

import javax.persistence.Column;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.*;
import java.util.List;

/**
 * Created by Guest Lector on 08-Aug-17.
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class PhotographerXmlExpotDto {

    @XmlTransient
    private String firstName;

    @XmlTransient
    private String lastName;

    @XmlTransient
    private String primaryCameraMake;

    @XmlTransient
    private String primaryCameraModel;

    @XmlElementWrapper(name = "lenses")
    @XmlElement(name = "lens")
    private List<LensExportXmlDto> lenses;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPrimaryCameraMake() {
        return primaryCameraMake;
    }

    public void setPrimaryCameraMake(String primaryCameraMake) {
        this.primaryCameraMake = primaryCameraMake;
    }

    public String getPrimaryCameraModel() {
        return primaryCameraModel;
    }

    public void setPrimaryCameraModel(String primaryCameraModel) {
        this.primaryCameraModel = primaryCameraModel;
    }

    public List<LensExportXmlDto> getLenses() {
        return lenses;
    }

    public void setLenses(List<LensExportXmlDto> lenses) {
        this.lenses = lenses;
    }

    @XmlAttribute(name = "name")
    public String getFullName() {
        return firstName + " " + lastName;
    }

    @XmlAttribute(name = "primary-camera")
    public String getPrimaryCameraInfo() {
        return primaryCameraMake + " " + primaryCameraModel;
    }
}
