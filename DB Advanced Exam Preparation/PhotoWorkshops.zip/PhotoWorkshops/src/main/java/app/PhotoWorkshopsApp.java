package app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by User on 23.7.2017 г..
 */
@SpringBootApplication
public class PhotoWorkshopsApp {

    public static void main(String[] args) {
        SpringApplication.run(PhotoWorkshopsApp.class, args);
    }
}
