package app.service.impl;

import app.dao.api.AccessoriesDao;
import app.model.entities.Accessory;
import app.service.api.AccessoriesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

/**
 * Created by Guest Lector on 08-Aug-17.
 */
@Service
@Transactional
public class AccessoriesServiceImpl implements AccessoriesService {

    @Autowired
    private AccessoriesDao accessoriesDao;

    @Override
    public List<Accessory> addAll(Iterable<Accessory> accessories) {
        return accessoriesDao.save(accessories);
    }
}
