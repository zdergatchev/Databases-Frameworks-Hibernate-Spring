package app.service.api;

import app.model.entities.Workshop;

import java.util.List;
import java.util.Map;

/**
 * Created by Guest Lector on 08-Aug-17.
 */
public interface WorkshopsService {

    Workshop addWorkshop (Workshop workshop);

    Map<String, List<Workshop>> findWorkshopsByLocations ();

}
