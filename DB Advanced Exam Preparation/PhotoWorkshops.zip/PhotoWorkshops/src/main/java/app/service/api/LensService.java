package app.service.api;

import app.model.entities.Lens;
import org.springframework.stereotype.Service;

import java.util.Iterator;
import java.util.List;

/**
 * Created by Guest Lector on 08-Aug-17.
 */
public interface LensService {

    List<Lens> addAll(Iterable<Lens> lenses);

    List<Lens> findByIdIn(Iterable<Long> id);
}
