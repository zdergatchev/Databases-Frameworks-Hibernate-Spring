package app.service.api;

import app.model.entities.Accessory;
import app.model.entities.Lens;

import java.util.List;

/**
 * Created by Guest Lector on 08-Aug-17.
 */
public interface AccessoriesService {

    List<Accessory> addAll(Iterable<Accessory> accessories);

}
