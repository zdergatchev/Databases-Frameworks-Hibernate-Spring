package app.service.impl;

import app.dao.api.LensesDao;
import app.model.entities.Lens;
import app.service.api.LensService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

/**
 * Created by Guest Lector on 08-Aug-17.
 */
@Service
@Transactional
public class LensesServiceImpl implements LensService {

    @Autowired
    private LensesDao lensesDao;

    @Override
    public List<Lens> addAll(Iterable<Lens> lenses) {
        return lensesDao.save(lenses);
    }

    @Override
    public List<Lens> findByIdIn(Iterable<Long> ids) {
        return lensesDao.findByIdIn(ids);
    }
}
