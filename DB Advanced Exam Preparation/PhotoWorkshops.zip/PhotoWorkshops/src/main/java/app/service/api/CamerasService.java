package app.service.api;

import app.model.entities.BasicCamera;

/**
 * Created by Guest Lector on 08-Aug-17.
 */
public interface CamerasService {

    BasicCamera add(BasicCamera camera);
}
