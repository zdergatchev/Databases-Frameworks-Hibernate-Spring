package app.service.impl;

import app.dao.api.CamerasDao;
import app.model.entities.BasicCamera;
import app.model.validation.ValidationUtil;
import app.service.api.CamerasService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

/**
 * Created by Guest Lector on 08-Aug-17.
 */
@Service
@Transactional
public class CamerasServiceImpl implements CamerasService {

    @Autowired
    private CamerasDao camerasDao;

    @Override
    public BasicCamera add(BasicCamera camera) {
        BasicCamera persistedCamera = null;
        if (ValidationUtil.isValid(camera)) {
            persistedCamera = camerasDao.save(camera);
            System.out.println("Successfully imported " + camera);
        } else {
            System.out.println("Error. Invalid data provided");
        }
        return persistedCamera;
    }
}
