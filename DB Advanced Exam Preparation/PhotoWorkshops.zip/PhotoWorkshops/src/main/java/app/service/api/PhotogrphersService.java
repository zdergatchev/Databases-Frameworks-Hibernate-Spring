package app.service.api;

import app.model.entities.Photographer;

import java.util.List;

/**
 * Created by Guest Lector on 08-Aug-17.
 */
public interface PhotogrphersService {

    Photographer addPhotographer(Photographer photographer, Iterable<Long> lensIds);

    List<Photographer> findAllOrdered ();

    List<Photographer> findAllWithSameCameras ();

    List<Photographer> findLandscapePhotographers ();
}
