package app.service.impl;

import app.dao.api.CamerasDao;
import app.dao.api.LensesDao;
import app.dao.api.PhotographersDao;
import app.model.entities.BasicCamera;
import app.model.entities.DSLRCamera;
import app.model.entities.Lens;
import app.model.entities.Photographer;
import app.model.validation.ValidationUtil;
import app.service.api.PhotogrphersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Created by Guest Lector on 08-Aug-17.
 */
@Service
@Transactional
public class PhotographersServiceImpl implements PhotogrphersService {

    @Autowired
    private LensesDao lensesDao;

    @Autowired
    private PhotographersDao photographersDao;

    @Autowired
    private CamerasDao camerasDao;

    @Override
    public Photographer addPhotographer(Photographer photographer, Iterable<Long> lensIds) {
        Photographer persistedPhotographer = null;
        addCameras(photographer);
        if(ValidationUtil.isValid(photographer)) {
            List<Lens> lenses = lensesDao.findByIdIn(lensIds);
            List<Lens> resultList = new ArrayList<>();
            for (Lens lens : lenses) {
                if(isCompatible(lens, photographer.getPrimaryCamera()) ||
                        isCompatible(lens, photographer.getSecondaryCamera())) {
                    lens.setOwner(photographer);
                    resultList.add(lens);
                } else {
                    System.out.println("Lense Is Not Compatible SORRY !!!");
                }

            }

            photographer.setLenses(resultList);

            persistedPhotographer = photographersDao.save(photographer);
            System.out.println("Successfully imported " + photographer);
        } else {
            System.out.println("Error. Invalid data provided");
        }
        return persistedPhotographer;
    }

    @Override
    public List<Photographer> findAllOrdered() {
        return photographersDao.findAllOrdered();
    }

    @Override
    public List<Photographer> findAllWithSameCameras() {
        return photographersDao.findAllWithSameCameras();
    }

    @Override
    public List<Photographer> findLandscapePhotographers() {
        List<Photographer> photographersWithSmallLenses = photographersDao.findPhotographersWithSmallLenses();
        List<Photographer> landscapePhotographers = new ArrayList<>();
        for (Photographer photographerWithSmallLens : photographersWithSmallLenses) {
            if(photographerWithSmallLens.getPrimaryCamera() instanceof DSLRCamera) {
                landscapePhotographers.add(photographerWithSmallLens);
            }
        }
        return landscapePhotographers;
    }

    private void addCameras(Photographer photographer) {
        Long count = camerasDao.count();
        long lId = ThreadLocalRandom.current().nextLong(1, count);
        if(photographer.getPrimaryCamera() == null) {
            photographer.setPrimaryCamera(camerasDao.findOne(lId));
        }

        lId = ThreadLocalRandom.current().nextLong(1, count);
        if(photographer.getSecondaryCamera() == null) {
            photographer.setSecondaryCamera(camerasDao.findOne(lId));
        }
    }

    private boolean isCompatible (Lens lens, BasicCamera camera) {
        return lens.getCompatibleWith() != null &&
                lens.getCompatibleWith().equals(camera.getMake());
    }
}
