package app.controller;


import app.model.dto.accessories.AccessoriesXmlDto;
import app.model.dto.cameras.CameraImportJsonDto;
import app.model.dto.lens.LensImpotJson;
import app.model.dto.photographers.*;
import app.model.dto.workshops.*;
import app.model.entities.*;
import app.parser.api.Serializer;
import app.parser.util.MappingUtil;
import app.service.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;


/**
 * Created by User on 23.7.2017 г..
 */
@Controller
public class Terminal implements CommandLineRunner {

    private final String LENSES_INPUT_JSON = "/files/json/input/lenses.json";
    private final String PHOTOGRAPHERS_INPUT_JSON = "/files/json/input/photographers.json";
    private final String WORKSHOPS_INPUT_XML = "/files/xml/input/workshops.xml";
    private final String ACCESSORIES_INPUT_XML = "/files/xml/input/accessories.xml";
    private final String CAMERAS_INPUT_JSON = "/files/json/input/cameras.json";
    private final String PHOTOGRAPHERS_ORDERED_OUTPUT_JSON = "src/main/resources/files/json/output/photographers-ordered.json";
    private final String PHOTOGRAPHERS_LANDSCAPE_OUTPUT_JSON = "src/main/resources/files/json/output/landscape-photographers.json";
    private final String PHOTOGRAPHERS_SAME_CAMERAS_OUTPUT_XML = "src/main/resources/files/xml/output/same-cameras-photographers.xml";
    private final String WORKSHOPS_BY_LOCATION_OUTPUT_XML = "src/main/resources/files/xml/output/workshops-by-location.xml";

    @Autowired
    @Qualifier(value = "JSONParser")
    private Serializer jsonSerializer;

    @Autowired
    @Qualifier(value = "XMLParser")
    private Serializer xmlSerializer;

    @Autowired
    private LensService lensService;

    @Autowired
    private CamerasService camerasService;

    @Autowired
    private PhotogrphersService photogrphersService;

    @Autowired
    private AccessoriesService accessoriesService;
    
    @Autowired
    private WorkshopsService workshopsService;

    @Override
    public void run(String... strings) throws Exception {
//        importLensesJson();
//        importCamerasJson();
//        importPhotographersJson();
//        importAccessoriesXml();
//        importWorkshposXml();

        exportPhotographersOrder();
        exportLanscapePhotographers();
        exportPhotographersWithSameCameras();
        exportWorkshopsByLocations();
    }

    private void exportWorkshopsByLocations() {
        LocationsWrapperXmlDto locationsWrapperXmlDto = new LocationsWrapperXmlDto();
        Map<String, List<Workshop>> workshopsByLocations = workshopsService.findWorkshopsByLocations();
        for (String location : workshopsByLocations.keySet()) {
            List<Workshop> workshops = workshopsByLocations.get(location);
            List<WorkshopExportXmlDto> workshopDtos = MappingUtil.convert(workshops, WorkshopExportXmlDto.class);
            LocationXmlEportDto locationDto = new LocationXmlEportDto();
            locationDto.setWorkshopExportXmlDtos(workshopDtos);
            locationDto.setName(location);
            locationsWrapperXmlDto.addLocationXmlEpxortDto(locationDto);
        }

        xmlSerializer.serialize(locationsWrapperXmlDto, WORKSHOPS_BY_LOCATION_OUTPUT_XML);
    }

    private void exportLanscapePhotographers() {
        List<Photographer> landscapePhotographers = photogrphersService.findLandscapePhotographers();
        List<LanscapePhotograpersJsonDto> lanscapePhotograpersJsonDtos = MappingUtil.convertLandscapePhotographers(landscapePhotographers);
        jsonSerializer.serialize(lanscapePhotograpersJsonDtos, PHOTOGRAPHERS_LANDSCAPE_OUTPUT_JSON);
    }

    private void exportPhotographersWithSameCameras() {
        List<Photographer> allWithSameCameras = photogrphersService.findAllWithSameCameras();
        List<PhotographerXmlExpotDto> convert = MappingUtil.convert(allWithSameCameras, PhotographerXmlExpotDto.class);
        PhotographersXmlExportDot photographersXmlExportDot = new PhotographersXmlExportDot();

        for (PhotographerXmlExpotDto photographerXmlExpotDto : convert) {
            if(photographerXmlExpotDto.getLenses().size() == 0) {
                photographerXmlExpotDto.setLenses(null);
            }
        }
        photographersXmlExportDot.setPhotographerXmlExpotDtos(convert);
        xmlSerializer.serialize(photographersXmlExportDot, PHOTOGRAPHERS_SAME_CAMERAS_OUTPUT_XML);
    }

    private void exportPhotographersOrder() {
        List<Photographer> allOrdered = photogrphersService.findAllOrdered();
        List<PhotographersOrderedExportJson> photographers = MappingUtil.convert(allOrdered, PhotographersOrderedExportJson.class);
        jsonSerializer.serialize(photographers, PHOTOGRAPHERS_ORDERED_OUTPUT_JSON);
    }

    private void importWorkshposXml() {
        WorkshopsImportXmlDto workshopsDto = xmlSerializer.deserialize(WorkshopsImportXmlDto.class, WORKSHOPS_INPUT_XML);
        for (WorkshopImportXmlDto workshopImportXmlDto : workshopsDto.getWorkshopImportXmlDtos()) {
            Workshop workshop = MappingUtil.convert(workshopImportXmlDto, Workshop.class);
            workshopsService.addWorkshop(workshop);
        }
    }

    private void importAccessoriesXml() {
        AccessoriesXmlDto accessoriesDto = xmlSerializer.deserialize(AccessoriesXmlDto.class, ACCESSORIES_INPUT_XML);
        List<Accessory> accessories = MappingUtil.convert(accessoriesDto.getAccessoryXMLDtos(), Accessory.class);
        accessoriesService.addAll(accessories);
    }

    private void importPhotographersJson() {
        PhotographerImportJsonDto[] photographerDtos = jsonSerializer.deserialize(PhotographerImportJsonDto[].class, PHOTOGRAPHERS_INPUT_JSON);
        for (PhotographerImportJsonDto photographerDto : photographerDtos) {
            Photographer photographer = MappingUtil.convert(photographerDto, Photographer.class);
            photogrphersService.addPhotographer(photographer, photographerDto.getLenses());
        }
    }

    private void importCamerasJson() {
        CameraImportJsonDto[] cameraDtos = jsonSerializer.deserialize(CameraImportJsonDto[].class, CAMERAS_INPUT_JSON);
        for (CameraImportJsonDto cameraDto : cameraDtos) {
            BasicCamera basicCamera = null;
            if("DSLR".equals(cameraDto.getType())) {
                basicCamera = MappingUtil.convert(cameraDto, DSLRCamera.class);
                camerasService.add(basicCamera);
            } else if ("Mirrorless".equals(cameraDto.getType())) {
                basicCamera = MappingUtil.convert(cameraDto, MirrorLesscamera.class);
                camerasService.add(basicCamera);
            }

        }



    }

    private void importLensesJson() {
        LensImpotJson[] lensDtos = jsonSerializer.deserialize(LensImpotJson[].class, LENSES_INPUT_JSON);
        List<Lens> lenses = MappingUtil.convert(Arrays.asList(lensDtos), Lens.class);
        lensService.addAll(lenses);
    }

}
