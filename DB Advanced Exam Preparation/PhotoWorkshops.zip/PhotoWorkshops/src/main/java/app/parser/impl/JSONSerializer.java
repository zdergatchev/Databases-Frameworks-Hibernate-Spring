package app.parser.impl;

import app.parser.api.Serializer;
import app.parser.api.FileIO;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * Created by User on 23.7.2017 г..
 */
@Component(value = "JSONParser")
public class JSONSerializer implements Serializer {

    @Autowired
    private FileIO fileIO;

    private Gson gson;

    public JSONSerializer() {
        gson = new GsonBuilder()
                .excludeFieldsWithoutExposeAnnotation()
                .setPrettyPrinting()
                .serializeNulls()
                .create();
    }

    @Override
    public <T> T deserialize(Class<T> className, String fileName) {
        String file = "";
        try {
            file = this.fileIO.read(fileName);
            T object = this.gson.fromJson(file, className);
            return object;
        } catch (IOException e) {
            // log here
            throw new SerializationException("Could not deserialize to class " + className + " from file : " + fileName, e);
        }
    }

    @Override
    public <T> void serialize(T t, String fileNameW) {
        String jsonContent = gson.toJson(t);
        try {
            this.fileIO.write(fileNameW, jsonContent);
        } catch (IOException e) {
            //log here
            throw new SerializationException("Could not serialize : " + jsonContent + " to file : " + fileNameW, e);
        }
    }
}
