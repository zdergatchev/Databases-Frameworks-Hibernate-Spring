package app.parser.util;

import app.model.dto.photographers.LanscapePhotograpersJsonDto;
import app.model.entities.Photographer;
import org.modelmapper.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class MappingUtil {

    private static ModelMapper modelMapper = new ModelMapper();

    public static <S, D> D convert(S source, Class<D> destinationClass) {
        D convertedObject = null;
        convertedObject = modelMapper.map(source, destinationClass);
        return convertedObject;
    }

    public static <S, D> D convert(S source, Class<D> destinationClass, PropertyMap<S, D> propertyMap) {
        D convertedObject = null;
        modelMapper.addMappings(propertyMap);
        convertedObject = modelMapper.map(source, destinationClass);
        return convertedObject;
    }

    public static <S, D> List<D> convert(Iterable<S> sourceList, Class<D> destinationClass) {
        List<D> resultList = new ArrayList<>();
        for (S s : sourceList) {
            D convertedObject = modelMapper.map(s, destinationClass);
            resultList.add(convertedObject);
        }

        return resultList;
    }

    public static List<LanscapePhotograpersJsonDto> convertLandscapePhotographers(Iterable<Photographer> photographers) {
        PropertyMap<Photographer, LanscapePhotograpersJsonDto> propMap = new PropertyMap<Photographer, LanscapePhotograpersJsonDto>() {
            @Override
            protected void configure() {
                map().setLensCount(source.getLenses().size());
            }
        };

        modelMapper.addMappings(propMap);

        List<LanscapePhotograpersJsonDto> resultList = convert(photographers, LanscapePhotograpersJsonDto.class);
        return resultList;
    }


}
