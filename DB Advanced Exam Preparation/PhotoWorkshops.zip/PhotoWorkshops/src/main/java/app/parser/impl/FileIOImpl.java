package app.parser.impl;

import app.parser.api.FileIO;
import org.springframework.stereotype.Component;

import java.io.*;

/**
 * Created by User on 23.7.2017 г..
 */
@Component
public class FileIOImpl implements FileIO {

    @Override
    public String read(String fileName) throws IOException {
        StringBuilder contentBuilder = new StringBuilder();
        InputStream is = getClass().getResourceAsStream(fileName);
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {
            String line;
            while ((line = reader.readLine()) != null) {
                contentBuilder.append(line);
            }
        }
        return contentBuilder.toString();
    }

    @Override
    public void write(String fileName, String content) throws IOException {
        File f = new File(fileName);
        if (!f.exists()) {
            f.getParentFile().mkdirs();
            f.createNewFile();
        }

        OutputStream outputStream = new FileOutputStream(f);
        try (BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream))) {
            bufferedWriter.write(content);
        }

    }
}
