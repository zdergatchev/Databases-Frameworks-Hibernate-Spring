package app.dao.api;

import app.model.entities.Workshop;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * Created by Guest Lector on 08-Aug-17.
 */
@Repository
public interface WorkshopsDao extends JpaRepository<Workshop, Long> {

    @Query(value = "SELECT DISTINCT w.location FROM Workshop AS w")
    List<String> findAllLocations();

    @Query(value = "SELECT w FROM Workshop AS w " +
            "INNER JOIN w.participants AS p " +
            "WHERE w.location = :loc GROUP BY w HAVING COUNT (p) >= 5")
    List<Workshop> findWorkshopsByLocation (@Param(value = "loc") String location);
}
