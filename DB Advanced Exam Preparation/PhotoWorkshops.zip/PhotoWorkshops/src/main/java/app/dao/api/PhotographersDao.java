package app.dao.api;

import app.model.entities.Photographer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by Guest Lector on 08-Aug-17.
 */
@Repository
public interface PhotographersDao extends JpaRepository<Photographer, Long> {

    Photographer findByFirstNameAndLastName(String firstName, String lastName);

    @Query(value = "SELECT p FROM Photographer AS p ORDER BY p.firstName ASC , p.lastName DESC")
    List<Photographer> findAllOrdered ();

    @Query(value = "SELECT p FROM Photographer AS p WHERE p.primaryCamera.make = p.secondaryCamera.make")
    List<Photographer> findAllWithSameCameras ();

    @Query(value = "SELECT DISTINCT p FROM Photographer AS p INNER JOIN p.lenses AS l WHERE l.focalLength <= 30 ORDER BY p.firstName ASC")
    List<Photographer> findPhotographersWithSmallLenses ();
}
