package app.dao.api;

import app.model.entities.Accessory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by Guest Lector on 08-Aug-17.
 */
@Repository
public interface AccessoriesDao extends JpaRepository<Accessory, Long> {
}
