package app.dao.api;

import app.model.entities.Lens;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

/**
 * Created by Guest Lector on 08-Aug-17.
 */
@Repository
public interface LensesDao extends JpaRepository<Lens, Long> {

    List<Lens> findByIdIn(Iterable<Long> id);
}
