package size;

public enum Size {
    SMALL, MEDIUM, LARGE
}
