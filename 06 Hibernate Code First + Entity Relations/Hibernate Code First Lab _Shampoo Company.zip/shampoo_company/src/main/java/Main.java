import label.BasicLabel;
import shampoo.FreshNuke;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory managerFactory = Persistence
                .createEntityManagerFactory("shampoo_company");
        EntityManager em = managerFactory.createEntityManager();
        em.getTransaction().begin();

        BasicLabel label = new BasicLabel("Fresh Nuke Shampoo");
        label.setSubtitle("alabala");
        FreshNuke freshNuke = new FreshNuke(label);
        //em.persist(label);

        em.persist(freshNuke);


        em.getTransaction().commit();
        em.close();
    }
}

