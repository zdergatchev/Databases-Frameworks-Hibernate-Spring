package batch;

public class ProductionBatch {
}
