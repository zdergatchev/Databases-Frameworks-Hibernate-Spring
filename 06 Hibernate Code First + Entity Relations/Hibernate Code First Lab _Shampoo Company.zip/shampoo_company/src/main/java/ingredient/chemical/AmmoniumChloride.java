package ingredient.chemical;

import java.math.BigDecimal;

public class AmmoniumChloride extends BasicChemicalIngredient {

    public static final String NAME = "AmmoniumChloride";
    public static final BigDecimal PRICE = BigDecimal.valueOf(0.59);
    public static final String CHEMICAL_FORMULA = "NH4Cl";

    public AmmoniumChloride() {
        super(NAME, PRICE, CHEMICAL_FORMULA);
    }
}
