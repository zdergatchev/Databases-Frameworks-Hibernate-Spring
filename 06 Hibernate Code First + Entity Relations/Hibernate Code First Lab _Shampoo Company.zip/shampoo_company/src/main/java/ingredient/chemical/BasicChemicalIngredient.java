package ingredient.chemical;

import ingredient.basic.BasicIngredient;

import java.math.BigDecimal;

public abstract class BasicChemicalIngredient
        extends BasicIngredient
        implements ChemicalIngredient {

    private String chemicaFormula;

    public BasicChemicalIngredient(String ammoniumChloride, double v) {
    }

    public BasicChemicalIngredient(String name, BigDecimal price, String chemicaFormula) {
        super(name, price);
        this.chemicaFormula = chemicaFormula;
    }

    public String getChemicaFormula() {
        return chemicaFormula;
    }

    public void setChemicaFormula(String chemicaFormula) {
        this.chemicaFormula = chemicaFormula;
    }
}
