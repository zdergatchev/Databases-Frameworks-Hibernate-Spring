package ingredient.basic;

import java.math.BigDecimal;

public class Lavender extends BasicIngredient {

    public static final String NAME = "Lavender";
    public static final BigDecimal PRICE = BigDecimal.valueOf(2);

    public Lavender() {
        super(NAME, PRICE);
    }
}
