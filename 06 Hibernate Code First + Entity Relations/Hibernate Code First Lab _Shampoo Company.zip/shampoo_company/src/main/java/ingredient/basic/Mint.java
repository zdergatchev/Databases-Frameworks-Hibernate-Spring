package ingredient.basic;

import java.math.BigDecimal;

public class Mint extends BasicIngredient {

    public static final String NAME = "Mint";
    public static final BigDecimal PRICE = BigDecimal.valueOf(3.54);

    public Mint(String name, BigDecimal price) {
        super(NAME, PRICE);
    }
}
