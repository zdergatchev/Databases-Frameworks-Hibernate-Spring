package ingredient.basic;

import java.math.BigDecimal;

public class Nettle extends BasicIngredient {

    public static final String NAME = "Nettle";
    public static final BigDecimal PRICE = BigDecimal.valueOf(6.12);

    public Nettle() {
        super(NAME, PRICE);
    }
}
