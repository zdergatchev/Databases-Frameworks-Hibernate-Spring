package ingredient.basic;

import java.math.BigDecimal;

public class Strawberry extends BasicIngredient {

    public static final String NAME = "Strawberry";
    public static final BigDecimal PRICE = BigDecimal.valueOf(4.85);

    public Strawberry() {
        super(NAME, PRICE);
    }
}
