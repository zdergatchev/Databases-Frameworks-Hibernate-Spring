package shampoo;

import batch.ProductionBatch;
import ingredient.basic.BasicIngredient;
import label.BasicLabel;
import size.Size;

import javax.persistence.Entity;
import java.math.BigDecimal;
import java.util.Set;

@Entity
public class FreshNuke extends BasicShampoo{

    public static final String NAME = "Fresh Nuke";
    public static final BigDecimal PRICE = BigDecimal.valueOf(9.33);

    public FreshNuke(BasicLabel label) {
        super(NAME, Size.LARGE, label, PRICE);
    }

    public FreshNuke() {
    }

    public ProductionBatch getBatch() {
        return null;
    }

    public void setBatch(ProductionBatch batch) {

    }

    public Set<BasicIngredient> getIngredients() {
        return null;
    }

    public void setIngredients(Set<BasicIngredient> ingredients) {

    }
}
