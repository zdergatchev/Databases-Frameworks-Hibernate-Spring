package shampoo;

import batch.ProductionBatch;
import ingredient.basic.BasicIngredient;
import label.BasicLabel;
import size.Size;

import javax.persistence.Entity;
import java.math.BigDecimal;
import java.util.Set;

@Entity
public class PinkPanther extends BasicShampoo {
    private static final String NAME = "Pink Panther";
    private static final BigDecimal PRICE = new BigDecimal(8.50);

    public PinkPanther() {
    }

    public PinkPanther(BasicLabel label){
        super(NAME, Size.MEDIUM, label, PRICE);
    }

    public ProductionBatch getBatch() {
        return null;
    }

    public void setBatch(ProductionBatch batch) {

    }

    public Set<BasicIngredient> getIngredients() {
        return null;
    }

    public void setIngredients(Set<BasicIngredient> ingredients) {

    }
}
