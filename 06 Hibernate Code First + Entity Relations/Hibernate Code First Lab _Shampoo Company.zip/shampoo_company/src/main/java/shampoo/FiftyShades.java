package shampoo;

import batch.ProductionBatch;
import ingredient.basic.BasicIngredient;
import label.BasicLabel;
import size.Size;

import javax.persistence.Entity;
import java.math.BigDecimal;
import java.util.Set;

@Entity
public class FiftyShades extends BasicShampoo {
    private static final String NAME = "Fifty Shades";
    private static final BigDecimal PRICE = new BigDecimal(6.69);

    public FiftyShades() {
    }

    public FiftyShades(BasicLabel label){
        super(NAME, Size.SMALL, label, PRICE);
    }

    public ProductionBatch getBatch() {
        return null;
    }

    public void setBatch(ProductionBatch batch) {

    }

    public Set<BasicIngredient> getIngredients() {
        return null;
    }

    public void setIngredients(Set<BasicIngredient> ingredients) {

    }
}
