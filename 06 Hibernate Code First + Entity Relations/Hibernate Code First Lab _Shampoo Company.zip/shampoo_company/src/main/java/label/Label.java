package label;

import shampoo.BasicShampoo;

interface Label {

    int getId();

    void setId(int id);

    String getTitle();

    void setTitle(String title);

    BasicShampoo getShampoo();

    void setShampoo(BasicShampoo shampoo);

    String getSubtitle();

    void setSubtitle(String subtitle);
}
