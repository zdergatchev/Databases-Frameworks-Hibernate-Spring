package _06FootballBettingDatabase.FootballDatabase;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "countries_continents")
public class CountryContinent implements Serializable{
    private Country country;
    private Continent continent;

    public CountryContinent() {
    }

    @Id
    @OneToOne
    @JoinColumn(name = "country_id")
    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    @Id
    @OneToOne
    @JoinColumn(name = "continent_id")
    public Continent getContinent() {
        return continent;
    }

    public void setContinent(Continent continent) {
        this.continent = continent;
    }
}
