package _06FootballBettingDatabase.FootballDatabase;

import javax.persistence.*;

@Entity
@Table(name = "teams")
public class Team {
    private int id;
    private String name;
    private byte[] logo;
    private String initials;
    private String primaryKitColor;
    private String secondaryKitColor;
    private Town town;
    private double budget;

    public Team() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(name = "logo", columnDefinition = "blob")
    public byte[] getLogo() {
        return logo;
    }

    public void setLogo(byte[] logo) {
        this.logo = logo;
    }

    @Column(name = "initials", length = 3)
    public String getInitials() {
        return initials;
    }

    public void setInitials(String initials) {
        this.initials = initials;
    }

    @Column(name = "primary_kit_color")
    public String getPrimaryKitColor() {
        return primaryKitColor;
    }

    public void setPrimaryKitColor(String primaryKitColor) {
        this.primaryKitColor = primaryKitColor;
    }

    @Column(name = "secondary_kit_color")
    public String getSecondaryKitColor() {
        return secondaryKitColor;
    }

    public void setSecondaryKitColor(String secondaryKitColor) {
        this.secondaryKitColor = secondaryKitColor;
    }

    @OneToOne
    @JoinColumn(name = "town_id")
    public Town getTown() {
        return town;
    }

    public void setTown(Town town) {
        this.town = town;
    }

    @Column(name = "budget")
    public double getBudget() {
        return budget;
    }

    public void setBudget(double budget) {
        this.budget = budget;
    }
}
