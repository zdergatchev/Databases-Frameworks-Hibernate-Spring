package _06FootballBettingDatabase.FootballDatabase;

import javax.persistence.*;

@Entity
@Table(name = "competition_type")
public class CompetitionType {
    private int id;
    private String name;

    public CompetitionType() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "type")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
