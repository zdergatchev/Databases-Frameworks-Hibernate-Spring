package _06FootballBettingDatabase.FootballDatabase;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "bets")
public class Bet {
    private int id;
    private double betMoney;
    private Date dateAndTimeOfBet;
    private User user;

    public Bet() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "bet_money", columnDefinition = "DOUBLE")
    public double getBetMoney() {
        return betMoney;
    }

    public void setBetMoney(double betMoney) {
        this.betMoney = betMoney;
    }

    @Column(name = "date_time", columnDefinition = "DATETIME")
    public Date getDateAndTimeOfBet() {
        return dateAndTimeOfBet;
    }

    public void setDateAndTimeOfBet(Date dateAndTimeOfBet) {
        this.dateAndTimeOfBet = dateAndTimeOfBet;
    }

    @OneToOne
    @JoinColumn(name = "user_id")
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
