package _06FootballBettingDatabase.FootballDatabase;

import javax.persistence.*;

@Entity
@Table(name = "result_predictions")
public class ResultPrediction {
    private int id;
    private String prediction;

    public ResultPrediction() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "prediction")
    public String getPrediction() {
        return prediction;
    }

    public void setPrediction(String prediction) {
        this.prediction = prediction;
    }
}
