import annotations.Entity;
import entities.ExampleEntity;
import entities.User;
import orm.Connector;
import orm.EntityManager;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws SQLException, IllegalAccessException, InstantiationException {
        Scanner scanner = new Scanner(System.in);
        // String username = scanner.nextLine().trim();
        // String password = scanner.nextLine().trim();
        // String db = scanner.nextLine().trim();

        Connector.createConnection("root","1234","orm_db");

        EntityManager em = new EntityManager<>(Connector.getConnection());

        //  insert user
//        User user = new User("nakov", 19, new Date(), new Date());
//        em.persist(user);

//        ExampleEntity example = new ExampleEntity("Stamat Stamatov", "Pernik");
//        em.persist(example);


        //   update user
//        User user = new User("nakov", 20, new Date(), new Date());
//        user.setId(1);
//        em.persist(user);

        //   find first user
//        User user = em.findFirst( User.class);
//        System.out.printf("Id: %s Name: %s Age: %s Date Registration: %s\n",
//                user.getId(), user.getUsername(), user.getAge(), user.getRegistrationDate());

        //   find first user with where
//        User user = em.findFirst( User.class, "id > 1");
//        System.out.printf("Id: %s Name: %s Age: %s Date Registration: %s\n",
//                user.getId(), user.getUsername(), user.getAge(), user.getRegistrationDate());

        //   find users
//        Iterable<User> users = em.find(User.class);
//        users.forEach(u -> {
//            System.out.printf("Id: %s Name: %s Age: %s Date Registration: %s\n",
//                    u.getId(), u.getUsername(), u.getAge(), u.getRegistrationDate());
//        });

        //   find users with where
//        Iterable<User> users = em.find(User.class, "id IN (1, 5, 11)");
//        users.forEach(u -> {
//            System.out.printf("Id: %s Name: %s Age: %s Date Registration: %s\n",
//                    u.getId(), u.getUsername(),u.getAge(), u.getRegistrationDate());
//        });

    }
}
