package entities;


import annotations.Column;
import annotations.Entity;
import annotations.Id;

@Entity(name = "example_entity")
public class ExampleEntity {
    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "first_name")
    private String first_name;

    @Column(name = "town")
    private String town;

    public ExampleEntity (String first_name, String town) {
        this.first_name = first_name;
        this.town = town;
    }
}
