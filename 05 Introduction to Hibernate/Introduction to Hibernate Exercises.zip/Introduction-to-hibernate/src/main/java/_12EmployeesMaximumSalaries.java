import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;

public class _12EmployeesMaximumSalaries {
    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("soft_uni");
        EntityManager em = factory.createEntityManager();

        em.getTransaction().begin();

        List<String[]> departmentsByMaxSalary = em.createQuery("SELECT e.department.name, MAX(e.salary) FROM Employee e " +
                "GROUP BY e.department HAVING MAX(e.salary) < 30000 OR MAX(e.salary) > 70000")
                .getResultList();

        em.getTransaction().commit();

        for (Object[] object : departmentsByMaxSalary) {
            System.out.printf("%s - (%.2f)%n", object[0], object[1]);
        }
    }
}
