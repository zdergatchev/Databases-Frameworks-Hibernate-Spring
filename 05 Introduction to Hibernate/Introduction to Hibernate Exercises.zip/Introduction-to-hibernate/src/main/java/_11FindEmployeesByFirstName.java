import entities.Employee;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;
import java.util.Scanner;

public class _11FindEmployeesByFirstName {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine().trim();

        EntityManagerFactory factory = Persistence.createEntityManagerFactory("soft_uni");
        EntityManager em = factory.createEntityManager();

        em.getTransaction().begin();

        List<Employee> employeeList = em.createQuery("SELECT e FROM Employee e WHERE e.firstName LIKE  ?")
                .setParameter(0, input + "%")
                .getResultList();

        em.getTransaction().commit();

        for (Employee employee: employeeList) {
            System.out.printf("%s %s - %s - (%.2f)%n", employee.getFirstName(),
                    employee.getLastName(), employee.getJobTitle(), employee.getSalary());
        }
    }
}
