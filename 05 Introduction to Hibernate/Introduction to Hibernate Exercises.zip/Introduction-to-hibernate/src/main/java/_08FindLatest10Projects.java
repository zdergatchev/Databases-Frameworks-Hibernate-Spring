import entities.Project;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;
import java.util.stream.Collectors;

public class _08FindLatest10Projects {
    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("soft_uni");
        EntityManager em = factory.createEntityManager();

        em.getTransaction().begin();

        List<Project> projectList = em.createQuery("SELECT p FROM Project p WHERE p.endDate IS NULL ORDER BY p.startDate DESC")
                .setMaxResults(10)
                .getResultList();

        List<Project> projects = projectList.stream()
                .sorted((p1, p2) -> p1.getName().compareTo(p2.getName()))
                .collect(Collectors.toList());

        for (Project proj: projects) {
            System.out.printf("Project name: %s%n " +
                                 "\tProject Description: %s%n " +
                                 "\tProject Start Date: %s%n " +
                                 "\tProject End Date: %s%n", proj.getName(), proj.getDescription(),
                                   proj.getStartDate(), proj.getEndDate());
        }

        em.getTransaction().commit();
    }
}
