import entities.Address;
import entities.Employee;
import entities.Town;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class _10RemoveTowns {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine().trim();

        EntityManagerFactory factory = Persistence.createEntityManagerFactory("soft_uni");
        EntityManager em = factory.createEntityManager();

        em.getTransaction().begin();

        List<Address> addressesByTown = em.createQuery("SELECT a FROM Address a WHERE a.town.name = ?")
                .setParameter(0, input)
                .getResultList();

        for (Address address : addressesByTown) {
            Set<Employee> employeeSet = address.getEmployees();
            for (Employee employee : employeeSet) {
                employee.setAddress(null);
            }
            em.remove(address);
        }

        Town town = (Town) em.createQuery("SELECT t FROM Town t WHERE t.name = ?")
                .setParameter(0, input)
                .getSingleResult();
        em.remove(town);

        em.getTransaction().commit();

        if (addressesByTown.size() == 1) {
            System.out.printf("%s address in %s deleted", addressesByTown.size(), input);
        } else {
            System.out.printf("%s addresses in %s deleted", addressesByTown.size(), input);
        }
    }
}
