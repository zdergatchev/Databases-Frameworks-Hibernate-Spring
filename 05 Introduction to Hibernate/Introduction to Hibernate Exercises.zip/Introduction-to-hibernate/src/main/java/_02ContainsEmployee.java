import entities.Employee;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;
import java.util.Scanner;

public class _02ContainsEmployee {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        EntityManagerFactory factory = Persistence.createEntityManagerFactory("soft_uni");
        EntityManager em = factory.createEntityManager();


        String[] input = scanner.nextLine().split("\\s+");
        String firstName = input[0];
        String lastName = input[1];

        em.getTransaction().begin();

        List<Employee> employeeList = em.createQuery("SELECT e FROM Employee e WHERE e.firstName LIKE ? AND e.lastName LIKE ?")
                .setParameter(0, firstName)
                .setParameter(1, lastName)
                .getResultList();

        if (employeeList.size() == 1) {
            System.out.println("Yes");
        } else {
            System.out.println("No");
        }

        em.getTransaction().commit();
    }
}
