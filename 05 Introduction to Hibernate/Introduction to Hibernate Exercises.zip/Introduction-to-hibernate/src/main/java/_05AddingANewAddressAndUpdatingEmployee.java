import entities.Address;
import entities.Employee;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.Scanner;

public class _05AddingANewAddressAndUpdatingEmployee {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String lastName = scanner.nextLine().trim();

        EntityManagerFactory factory = Persistence.createEntityManagerFactory("soft_uni");
        EntityManager em = factory.createEntityManager();
        em.getTransaction().begin();

        Address newAddress = new Address();
        newAddress.setText("Musala 17");
        em.persist(newAddress);

        Employee employee = (Employee) em.createQuery("SELECT e FROM Employee e " +
                "WHERE e.lastName = ?").setParameter(0, lastName)
                .setMaxResults(1)
                .getSingleResult();

        employee.setAddress(newAddress);
        em.getTransaction().commit();
    }
}
