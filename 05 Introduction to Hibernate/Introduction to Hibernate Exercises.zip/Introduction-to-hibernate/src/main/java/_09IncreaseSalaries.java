import entities.Employee;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.math.BigDecimal;
import java.util.List;

public class _09IncreaseSalaries {
    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("soft_uni");
        EntityManager em = factory.createEntityManager();

        em.getTransaction().begin();

        List<Employee> employeeList = em.createQuery("SELECT e FROM  Employee e " +
                "WHERE e.department.name IN ('Engineering', 'Tool Design', 'Marketing', 'Information Services') " +
                "ORDER BY e.salary ASC, e.firstName ASC")
                .getResultList();

        for (Employee employee: employeeList) {
            BigDecimal salary = employee.getSalary().multiply(new BigDecimal(1.12));
            employee.setSalary(salary);
            em.persist(employee);
        }

        em.getTransaction().commit();

        for (Employee employee:employeeList) {
            System.out.printf("%s %s ($%.2f)%n",
                    employee.getFirstName(),
                    employee.getLastName(),
                    employee.getSalary());
        }
    }
}
