import entities.Employee;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;

public class _03EmployeesWithSalaryOver50000 {
    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("soft_uni");
        EntityManager em = factory.createEntityManager();
        em.getTransaction().begin();

        List<Employee> employeeList = em.createQuery("SELECT e FROM Employee e WHERE e.salary > 50000")
                .getResultList();

        em.getTransaction().commit();

        for (Employee employee:employeeList) {
            System.out.println(employee.getFirstName());
        }
    }
}
