import entities.Employee;
import entities.Project;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

public class _07GetEmployeeWithProject {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int employyId = scanner.nextInt();

        EntityManagerFactory factory = Persistence.createEntityManagerFactory("soft_uni");
        EntityManager em = factory.createEntityManager();

        em.getTransaction().begin();

        Employee employee = (Employee) em.createQuery("SELECT e FROM Employee e WHERE e.id = ?")
                .setParameter(0, employyId)
                .getSingleResult();

        Set<Project> employeeProjects = employee.getProjects()
                .stream()
                .sorted((p1, p2) -> p1.getName().compareTo(p2.getName()))
                .collect(Collectors.toSet());

        System.out.printf("%s %s - %s%n",
                employee.getFirstName(),
                employee.getLastName(),
                employee.getJobTitle());
        for (Project proj: employeeProjects) {
            System.out.printf("\t%s%n", proj.getName());
        }


        em.getTransaction().commit();
    }
}
