package app;

import app.serrvice.impl.ShampoosServiceImpl;
import app.service.api.IngredientService;
import app.service.api.ProductionBatchService;
import app.service.api.ShampoosService;
import app.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by User on 18.7.2017 г..
 */
@Component
public class ConsoleRunner implements CommandLineRunner{

    @Autowired
    private ProductionBatchService<ProductionBatch, Long> productionBatchService;

    @Autowired
    private IngredientService<BasicIngredient, Long> basicIngredientService;

    @Autowired
    private ShampoosService<BasicShampoos, Long> basicShampoosService;

    @Override
    public void run(String... strings) throws Exception {
        BasicIngredient i1 = new Mint();
        BasicIngredient i2 = new Mint();
        BasicIngredient i3 = new Strawberry();
        BasicIngredient i4 = new AmoniumCloride();
        basicIngredientService.save(i1);
        basicIngredientService.save(i2);
        basicIngredientService.save(i3);
        basicIngredientService.save(i4);
//
        BasicIngredient bi = basicIngredientService.findById(4l);
        BasicIngredient b1 = basicIngredientService.findById(3l);
        BasicIngredient b2 = basicIngredientService.findById(2l);
        BasicIngredient b3 = basicIngredientService.findById(1l);
        System.out.println(basicIngredientService.findByNameEndsWith("nt"));
//
        ClassicLabel label = new ClassicLabel("Fresh Shine");
        BasicShampoos shampoo = new FreshNuke();
        Set<BasicIngredient> ingredients = new HashSet<>();
        ingredients.add(i1);
        ingredients.add(i3);
        shampoo.setIngredients(ingredients);
        shampoo.setLabel(label);
        //em.persist(label);
        ProductionBatch batch = new ProductionBatch();
        batch.setName("FirstSeries");
        shampoo.setBatch(batch);
        basicShampoosService.save(shampoo);
        BasicShampoos shampoo1 = new FreshNuke();
        shampoo1.setIngredients(ingredients);
        shampoo1.setBatch(new ProductionBatch());
        shampoo1.setLabel(new ClassicLabel());
        basicShampoosService.save(shampoo1);

        ProductionBatch pb = productionBatchService.findById(1l);
        System.out.println(pb);


        List<ProductionBatch> batches = productionBatchService.findBatchByName("FirstSeries");
        System.out.println(batches);


        List<BasicShampoos> shampoos = basicShampoosService.shampoosWithIngredient(i1.getName());
        System.out.println(shampoos);

        List<BasicShampoos> shampoos1 = basicIngredientService.shampoosWithIngredient(i3);
        System.out.println(shampoos1);
    }
}
