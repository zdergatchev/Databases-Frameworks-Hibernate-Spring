package app.repository;

import app.domain.model.Person;
import app.domain.model.PhoneNumber;

/**
 * Created by User on 1.8.2017 г..
 */
public interface PersonRepositoryCustom {

    Person merge (Person person);
}
